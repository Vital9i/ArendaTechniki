// Конфигурация Telegram бота ТопАгроБел
// ВАЖНО: этот файл не попадает в Git — загрузите его на хостинг вручную

const TELEGRAM_CONFIG = {
  BOT_TOKEN: '8967975508:AAHM9A1Uv_oZr6g5AFQihAglq2hbh9uUCIY',
  CHAT_ID: '-1003248332317'
};

// Опционально: PHP-прокси на хостинге (токен тогда хранится в api/telegram-config.php)
// const LEAD_ENDPOINT = 'api/send-lead.php';
