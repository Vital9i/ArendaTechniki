<?php
// Не публикуйте этот файл в открытый репозиторий

return [
    'bot_token' => '8967975508:AAHM9A1Uv_oZr6g5AFQihAglq2hbh9uUCIY',
    'chat_id' => '-1003248332317',
];
